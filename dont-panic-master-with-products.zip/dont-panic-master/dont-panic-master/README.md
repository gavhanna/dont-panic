Server Side Web Technologies Class Project
===

TODO: add some info here

### Installation
* Clone this repo
* CD into directory
* run `bundle install`
* run `rails s -b $IP -p $PORT`
* Click the `Preview` tab and select `Preview running application`